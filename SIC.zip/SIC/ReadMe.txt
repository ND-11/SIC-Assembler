Hello, 

Simply this is a python program that will run pass one and two of a .asm file that the user has chosen, as a test I have attached a .asm file you may try yourself (under the name: input.asm).

AS COMMON SENSE a pass two will not run and an error occurs if you try to run it without running pass one first, so here how it goes

1. chose 'pass one' and open your file directory and pick the input file (make sure it's .asm)
2. Click on 'submit' and now two notepad pop-ups one with the Intermediate file and another SymbolTab
3. Go back to the main menu and click on 'pass two' and then on 'display' to show the object program

You may adjust the program and add restrictions or checkpoints somewhere.

Enjoy! ND.