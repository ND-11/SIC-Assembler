import ctypes
import tkinter as tk
import webbrowser
from tkinter import ttk
from tkinter import *
from tkinter import filedialog as fd
from tkinter.messagebox import askyesno
from tkinter.messagebox import showinfo

# Importing pass_one.py file
from pass_one import *


# ------------------------------------------------------------------------------------------------
# The window of PASS ONE
class Window1(tk.Toplevel):

    def __init__(self, parent):
        super().__init__(parent)

        # Setting the window size/ title and position in the screen
        self.geometry("295x175+605+280")
        self.title("SIC Assembler")
        self.iconbitmap("ico.ico")

        def open_file():
            # Opening the user's file dialogue and storing the directory in a variable
            open_file.filepath = fd.askopenfilename(title="Open an asm file")
            # Confirming and showing the info of the selected file
            showinfo(title="Selected File", message=open_file.filepath)

        def submitting():
            # Passing the directory to the pass_one file
            # A yes/no prompt window
            answer = askyesno(title="confirmation", message="Are you sure?")
            if answer:
                # Passing the directory to the pass_one file
                passOne(open_file.filepath)
                ctypes.windll.user32.MessageBoxW(0, "Done! \nThe intermediate file and symbol tabel file will open in your notepad",
                                                 "Information Message", 0)

                # Display the intermediate file and Symbol tabel in a notepad
                webbrowser.open("Intermediatefile.txt")
                webbrowser.open("SymbolTab.txt")

        # place labels and buttons on the window
        tk.Label(self, text="Pass One", fg="#c78340", font=("Helvetica", 13)).place(x=110, y=10)
        tk.Label(self, text="Select the input file", fg="#94612f", font=("Helvetica", 10)).place(x=87, y=40)
        tk.Label(self, text="*Make sure your file extension is .asm", fg="#962f37", font=("Helvetica", 8)).place(x=55, y=100)

        ttk.Button(self, text="Open a File", width=41,  command=open_file).place(x=20, y=72)
        ttk.Button(self, text="Back", command=self.back).place(x=20, y=130)
        ttk.Button(self, text="Submit", command=submitting).place(x=110, y=130)
        ttk.Button(self, text="Quit", command=self.quit).place(x=200, y=130)

    def quit(self):
        quit()

    def back(self):
        self.destroy()

# ------------------------------------------------------------------------------------------------
# The window of PASS TWO
class Window2(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)

        # Setting the window size/ title and position in the screen
        self.geometry("600x370+500+200")
        self.title("SIC Assembler")
        self.iconbitmap("ico.ico")

        # Display function to display the object program in the text box and reveal the OPN button and a label
        def Display():
            openOP = (open("ObjectProgram.txt", "r"))
            content = openOP.read()
            openOP.close()

            OPTextBox.configure(state="normal")
            OPTextBox.insert(END, content)
            OPTextBox.configure(state="disabled")
            dis["state"] = tk.DISABLED
            OPN["state"] = tk.NORMAL

        # A function to open the object program in a notepad + disabling the button
        def OPNotepad():
            webbrowser.open("ObjectProgram.txt")
            OPN["state"] = tk.DISABLED

        # place labels, buttons and text box on the window
        tk.Label(self, text="Pass Two", fg="#c78340", font=("Helvetica", 15)).place(x=240, y=10)
        tk.Label(self, text="Click display to reveal the object program", fg="#94612f", font=("Helvetica", 9)).place(x=160, y=40)
        tk.Label(self, text="The object program generated:", fg="#94612f", font=("Helvetica", 9)).place(x=9, y=65)

        ttk.Button(self, text="Back", command=self.back).place(x=20, y=325)
        ttk.Button(self, text="Quit", command=self.quit).place(x=506, y=325)
        OPN = ttk.Button(self, text="Open with notepad", command=OPNotepad)
        OPN["state"] = tk.DISABLED
        OPN.place(x=470, y=60)
        dis = ttk.Button(self, text="Display", width=60, command=Display)
        dis.place(x=118, y=325)

        OPTextBox = tk.Text(self, state="disabled", height=14, width=72)
        OPTextBox.place(x=10, y=90)


    def quit(self):
        quit()

    def back(self):
        self.destroy()


# ------------------------------------------------------------------------------------------------
# The first window contains two option button and a label
class App(tk.Tk):
    def __init__(self):
        super().__init__()

        # Setting the window size/ title and position in the screen
        self.geometry("305x135+600+300")
        self.title("SIC Assembler")
        self.iconbitmap("ico.ico")

        # place a labels and buttons on the root window
        # Info different between tk and tkk:
        # (https://stackoverflow.com/questions/19561727/what-is-the-difference-between-the-widgets-of-tkinter-and-tkinter-ttk-in-python)
        tk.Label(self, text="SIC Assembler", fg="#c78340", font=("Helvetica", 13)).place(x=93, y=13)
        tk.Label(self, text="Welcome to the SIC Assembler please choose\n which pass would you like?", fg="#94612f",
                 font=("Helvetica", 8)).place(x=40, y=40)
        ttk.Button(self, text="Pass One", command=self.OpenPassOneWindow).place(x=75, y=90)
        ttk.Button(self, text="Pass Two", command=self.OpenPassTwoWindow).place(x=160, y=90)

    def OpenPassOneWindow(self):
        window = Window1(self)
        window.grab_set()

    def OpenPassTwoWindow(self):
        window = Window2(self)
        window.grab_set()


if __name__ == "__main__":
    app = App()
    app.mainloop()
